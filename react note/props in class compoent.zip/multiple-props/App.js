import React from 'react';
import { Text, View } from 'react-native';

class Cat extends React.Component{
  render(){
    return(
      <View>
      <Text>Hello,I am {this.props.name}</Text>
      </View>
    )
  }
}
class Cafe extends React.Component{
  render(){
    return(
      <View>
      
      <Cat name="Maru"/>
      </View>
    )
  }
}

// const Cat = (props) => {
//   return (
//     <View>
//       <Text>Hello, I am {props.name}!</Text>
//     </View>
//   );
// }

// const Cafe = () => {
//   return (
//     <View>
//       <Cat name="Maru" />
//       <Cat name="Jellylorum" />
//       <Cat name="Spot" />
//     </View>
//   );
// }

export default Cafe;